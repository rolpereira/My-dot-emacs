<?php

	  Echo "why is this text red";

          /* It looks like there is some sync problem with php-mode
             here.  Adding a ( before the string makes the string
             beeing fontified as a string.
          */

?>
