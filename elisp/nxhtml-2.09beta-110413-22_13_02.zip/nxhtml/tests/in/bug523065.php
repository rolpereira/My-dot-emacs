
 <?php /* ?>
          This is a comment
       */
 ?>
 This is html
