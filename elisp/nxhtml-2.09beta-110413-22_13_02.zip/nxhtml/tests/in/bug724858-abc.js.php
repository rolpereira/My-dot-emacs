if (!window.abc)
  window.abc = {};
(function(window, $, undefined) {
    var abc_url;
})(window, window.abc);
