<html>
<head>
<title>foo</title>
</head>
<body>
  <?php var_dump
