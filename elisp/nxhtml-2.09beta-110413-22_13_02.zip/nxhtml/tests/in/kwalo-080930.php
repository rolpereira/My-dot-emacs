<?

class Baz
{
  // This class was written after the file was opened
}

class Bar
{
  public function foo()
  {
    var_dump("foo");
    return null;
  }
}

class Foo
{
  public function bar()
  {
    var_dump("bar");
  }
}