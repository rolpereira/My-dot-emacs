<?xml version="1.0" encoding="utf-8"?>
<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node text="Testnote">
<richcontent TYPE="NOTE"><html>
<head>
</head>
<body>
--org-mode:   :CLOCK:<br />
--org-mode:   my clock<br />
--org-mode:   :END:<br />
</body>
</html>
</richcontent>
</node>
</map>
